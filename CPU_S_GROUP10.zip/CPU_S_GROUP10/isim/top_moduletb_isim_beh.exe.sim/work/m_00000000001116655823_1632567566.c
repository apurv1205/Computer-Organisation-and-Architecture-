/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Apurv Kumar/Desktop/CPU_S_GROUP10/data_memory.v";



static void Always_15_0(char *t0)
{
    char t15[8];
    char t16[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    unsigned int t25;
    int t26;
    char *t27;
    unsigned int t28;
    int t29;
    int t30;
    unsigned int t31;
    unsigned int t32;
    int t33;
    int t34;

LAB0:    t1 = (t0 + 3712U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 4032);
    *((int *)t2) = 1;
    t3 = (t0 + 3744);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(16, ng0);

LAB5:    t4 = (t0 + 280);
    xsi_vlog_namedbase_setdisablestate(t4, &&LAB6);
    t5 = (t0 + 3520);
    xsi_vlog_namedbase_pushprocess(t4, t5);

LAB7:    xsi_set_current_line(17, ng0);
    t6 = (t0 + 2072U);
    t7 = *((char **)t6);
    t6 = (t7 + 4);
    t8 = *((unsigned int *)t6);
    t9 = (~(t8));
    t10 = *((unsigned int *)t7);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB8;

LAB9:
LAB10:    xsi_set_current_line(20, ng0);
    t2 = (t0 + 2232U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t8 = *((unsigned int *)t2);
    t9 = (~(t8));
    t10 = *((unsigned int *)t3);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB14;

LAB15:
LAB16:    t2 = (t0 + 280);
    xsi_vlog_namedbase_popprocess(t2);

LAB6:    t3 = (t0 + 3520);
    xsi_vlog_dispose_process_subprogram_invocation(t3);
    goto LAB2;

LAB8:    xsi_set_current_line(17, ng0);

LAB11:    xsi_set_current_line(18, ng0);
    t13 = (t0 + 1912U);
    t14 = *((char **)t13);
    t13 = (t0 + 2792);
    t17 = (t0 + 2792);
    t18 = (t17 + 72U);
    t19 = *((char **)t18);
    t20 = (t0 + 2792);
    t21 = (t20 + 64U);
    t22 = *((char **)t21);
    t23 = (t0 + 1752U);
    t24 = *((char **)t23);
    xsi_vlog_generic_convert_array_indices(t15, t16, t19, t22, 2, 1, t24, 16, 2);
    t23 = (t15 + 4);
    t25 = *((unsigned int *)t23);
    t26 = (!(t25));
    t27 = (t16 + 4);
    t28 = *((unsigned int *)t27);
    t29 = (!(t28));
    t30 = (t26 && t29);
    if (t30 == 1)
        goto LAB12;

LAB13:    goto LAB10;

LAB12:    t31 = *((unsigned int *)t15);
    t32 = *((unsigned int *)t16);
    t33 = (t31 - t32);
    t34 = (t33 + 1);
    xsi_vlogvar_assign_value(t13, t14, 0, *((unsigned int *)t16), t34);
    goto LAB13;

LAB14:    xsi_set_current_line(20, ng0);

LAB17:    xsi_set_current_line(21, ng0);
    t4 = (t0 + 2792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t0 + 2792);
    t13 = (t7 + 72U);
    t14 = *((char **)t13);
    t17 = (t0 + 2792);
    t18 = (t17 + 64U);
    t19 = *((char **)t18);
    t20 = (t0 + 1752U);
    t21 = *((char **)t20);
    xsi_vlog_generic_get_array_select_value(t15, 16, t6, t14, t19, 2, 1, t21, 16, 2);
    t20 = (t0 + 2632);
    xsi_vlogvar_assign_value(t20, t15, 0, 0, 16);
    goto LAB16;

}


extern void work_m_00000000001116655823_1632567566_init()
{
	static char *pe[] = {(void *)Always_15_0};
	xsi_register_didat("work_m_00000000001116655823_1632567566", "isim/top_moduletb_isim_beh.exe.sim/work/m_00000000001116655823_1632567566.didat");
	xsi_register_executes(pe);
}
